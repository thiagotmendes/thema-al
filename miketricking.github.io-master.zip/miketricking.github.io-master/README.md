# imagehover
html and css code for image hover effects with or without bootstrap

Have tested all individually in codepen using bootstrap.

TO DO:

Make all the effects fully responsive. Some are already/some need slight changes depending on sizes.

Create the effects using SASS.








Special thanks to:
 
codrops (http://tympanus.net/codrops/)
start boot strap (http://startbootstrap.com)
bootstrap (http://getbootstrap.com/)
font awesome (http://fortawesome.github.io/Font-Awesome/)
github (http://github.com)
unsplash for images (https://unsplash.com/)
font squirrel (http://fontsquirrel.com/)
codepen (http://codepen.com/)
